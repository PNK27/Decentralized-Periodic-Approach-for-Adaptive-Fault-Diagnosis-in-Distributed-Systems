#client

import socket 
import os
import sys

print "IN VLAN 30 server***********"
c=socket.socket(socket.AF_INET,socket.SOCK_STREAM)

host='172.16.30.101'
port=22361
address=host,port
c.bind(address)
c.listen(1)

s,addr=c.accept()


contents=s.recv(1024)
print contents

fv = open("fromothervlan.txt","w")
fv.write(contents)
fv.close()
print "Written for broadcasting"
os.system("python broadcastfromothervlan.py")

c.close()


'''
[root@localhost 3462]# systemctl stop firewalld.service
[root@localhost 3462]# systemctl stop iptables.service
[root@localhost 3462]# python socket1_clientpc.py
enter filenameabc.txt
Welcome To Cummins College.
'''

