START=$(date +%s)


python prob_leader_trial.py &
python recv.py &
python final_broadcast.py &
python vlan30server.py &
python recv_other_vlan_broadcast.py &


python selftest.py
python cmpself_test.py
python status.py


date=$(date +"%d-%m-%y")
END=$(date +%s)
DIFF=$(($END-$START))
