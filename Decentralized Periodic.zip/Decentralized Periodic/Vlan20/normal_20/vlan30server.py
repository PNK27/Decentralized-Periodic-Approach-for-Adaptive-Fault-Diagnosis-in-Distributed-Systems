import socket
import os
import sys


#___________________SERVER_______________________________________



''' A pair (host, port) is used for the AF_INET address family, where host is a string representing either a hostname in Internet domain notation like 'daring.cwi.nl' or an IPv4 address like '100.50.200.5', and port is an integer. '''





#while True:
	
s=socket.socket(socket.AF_INET,socket.SOCK_STREAM) 		
s.setsockopt(socket.SOL_SOCKET,socket.SO_REUSEADDR,1)

host='172.16.30.101'	#obtained by ifconfig command on server side.Copy same on client side
port=22353
addr=host,port
s.bind((addr))
s.listen(5)
c,addr=s.accept()


filename=c.recv(1024)

print "File Requested is:",filename
print "File requested By:",addr

fd= open(filename,"r")



contents=fd.read(1024)

c.send(contents)
print "File Sent To-----:",addr
fd.close()
c.close()
s.close()
'''
Note:
Client will enter the filename it wants which is present on the server side
'''


'''OUTPUT:
[ccoew@localhost ~]$ su
Password: 

[root@localhost ccoew]# systemctl stop firewalld.service
[root@localhost ccoew]# systemctl stop iptables.service
[root@localhost 3457]# python mysocket1.py
File Received: abc.txt
[root@localhost 3457]# 


'''


