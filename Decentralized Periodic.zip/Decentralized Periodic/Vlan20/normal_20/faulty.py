#serversend.py
import socket
import netifaces as ni
import csv
import os
import sys
import traceback
import time
from cmpself_test import *

    #print socket.gethostname()
    #print socket.gethostbyname(socket.gethostname())
    #print socket.gethostbyaddr(socket.gethostbyname(socket.gethostname()))
array=ni.interfaces()
print "array",array[1]
ni.ifaddresses(array[1])
ip = ni.ifaddresses(array[1])[2][0]['addr']
print "ip",ip
#msg = socket.gethostname()
msg = str(ip)+","+str(status)
print "msg in faulty with status = faulty = 1",msg
dest = ('<broadcast>',10100)
s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
s.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
#s.sendto(msg, dest)
print "Looking for replies; press Ctrl-C to stop."

count=0
timeout=time.time()+5
broadcast=0


#####################
#broadcast_received = 0
print "Client2"
host = ''
port = 10100
#msg="sent ACK"
#s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
#s.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
s.bind((host,port))
##################

flag2 = 0
flag = 0

broadcast_received = 0

if os.path.isfile("test.csv"):
	os.remove("test.csv")

if os.path.isfile("ack_sent.txt"):
	os.remove("ack_sent.txt")

if os.path.isfile("ack_received.txt"):
	os.remove("ack_received.txt")


if os.path.isfile("leader_volunteer.txt"):
	os.remove("leader_volunteer.txt")

'''def broadcastjump():
	print "In broadcast jump"
	global broadcast_received
	if(broadcast_received is 0):
		print "Calling trial"
		os.system("python trial.py")'''
		
#______________________________________________________________________________________________________
def got_volunteer():
	print "got_volunteer"
	print message
	global broadcast_received
	broadcast_received = 1		
	print "Got data from", address
	#broadcast_received = 1

	print "address formattttttttt",address
	ad = ''.join(str(address));
	ad1 = ad.split()
	print "ad1",ad1
	ad2= ad1[0]
	ad4=ad1[1]
	print "ad4",ad4
	print "ad2",ad2
	print "ad2+ad4",ad2+ad4
	data = ad2+ad4
	ad3=ad2[2:10]
	ad5=ad4[0:5]

	fa = open('leader_volunteer.txt', 'a')
	fr=open('leader_volunteer.txt','r')
	listss=fr.readlines()
	listss=set(listss)
	print "listss",listss
	if not listss:
	    fw = open('leader_volunteer.txt', 'w')
	    fw.write(ad3+'\n')
	    
	else:
	    found=False
	    fa = open('leader_volunteer.txt', 'a')
	    t=str(ad3)
	    for i in listss:
		print "In for"
		i=i.strip('\n')
		if any(t in s for s in listss):
		    print "Already exists in file"
		    found=True
		    break
		if not found:
		    print "In not found"
		    fa.write(ad3+'\n')
		    break
	    

	#print "Not Same stringgggggg so write"

	fr.close()


	if os.path.isfile("test.csv"):	#if already a leader has requsted for its acknowledgement
	   print "ALREADY SENT ACK. dO NOT SEND EVEN IF SOMEONE VOLUNTEERED"
	   flag = 1
	   #break
	   # os.remove("serverlist.txt")


	global flag 
	if(flag is 0):
		print "Sending ACKNOWLEDGEMENT FOR FIRST TIME"
		print "ad5",ad5
		print ad3
		with open('test.csv', 'a') as fp:
			f = csv.writer(fp, delimiter=',')
			f.writerow([ad3]+[ad5])
		fp.close()


       
		with open('test.csv','rb') as f1:
			for line in (f1.readlines()):
			    	#print line.rstrip()
				print "line",line
				#columns = line.rstrip().split(',')
				columns = line
				print columns
				print "Sending ack to: ",address[0]
				#s.sendto("sending ack from ip",(columns[0].strip(),columns[1].strip()))
				s.sendto(msg,(address[0],address[1]))

		f = open('ack_sent.txt', 'a')
		f.write(address[0])#leader selected by me
		f.close()   

	#os.system("python client3.py")
	print "After calling client"
	#break




#____________________________________________________________________________________
while 1:
	try:
		
		print "Checking if any volunteer has sent a broadcast"
		
		#if os.path.isfile("leader_volunteer.txt"):#if leader_volunteer file is present,means broadcast received
		print "Checking for a broadcast till timeout"
		while(True):			##########################
			#s.settimeout(5.0)
			if time.time()<timeout: 
				print "Now waiting to receive"
				message, address = s.recvfrom(10104)
				got_volunteer()
				break	####################### break for ###############while loop
			#print "In while TRUE loop"
			#os.system("python leader_select.py")
			#sys.exit()
			print "After calling file"
			break
			#____________CONTINUE FROM HERE__________	
		

		print "In while loop"
		




	except socket.timeout: #volunteer to become leader and send broadcast
		print "In timeout"
		#broadcastjump()
		print "Returned from  broadcast jump without calling trial as someone volunteered"


	except (KeyboardInterrupt, SystemExit):
		if os.path.isfile("test.csv"):
        		os.remove("test.csv")
        	raise
	except:
        	traceback.print_exc()
		if os.path.isfile("test.csv"):
        		os.remove("test.csv")



#____________________________________________________________________________________
'''if os.path.isfile("test.csv"):
	os.remove("test.csv")'''
	
	
