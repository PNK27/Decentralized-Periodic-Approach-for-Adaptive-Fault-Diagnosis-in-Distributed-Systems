import socket
import netifaces as ni
import os
import sys
import time

array=ni.interfaces()
#print "array",array[1]
ni.ifaddresses(array[1])
ip = ni.ifaddresses(array[1])[2][0]['addr']
print "ip",ip
print "Im in prob leader"
UDP_IP = ip	#self ip
UDP_PORT = 10110
UDP_PORT2 = 10101

timeout=time.time()+50

'''if os.path.isfile("all_volunteers.txt"):
	os.remove("all_volunteers.txt")'''

if os.path.isfile("ack_count.txt"):
	os.remove("ack_count.txt")

sock = socket.socket(socket.AF_INET, # Internet
                         socket.SOCK_DGRAM) # UDP
sock.setsockopt(socket.SOL_SOCKET,socket.SO_REUSEADDR,1)

sock.bind((UDP_IP, UDP_PORT))

#_________________________________________________________________
ss = socket.socket(socket.AF_INET, # Internet
                         socket.SOCK_DGRAM) # UDP
ss.setsockopt(socket.SOL_SOCKET,socket.SO_REUSEADDR,1)

ss.bind((UDP_IP, UDP_PORT2))

ack_count = 0
f1=open('all_volunteers.txt','a')
f2=open('ack_count.txt','w+')
while True: 

	#f1=open('all_volunteers.txt','w+')
        
	data, addr = sock.recvfrom(1024) # buffer size is 1024 bytes
	print "received message:", data
	
	#print "after file open" 
	
	
	f1.write(data)
	volunteer_count = 0
	with open('all_volunteers.txt','rb') as f1:
			for line in (f1.readlines()):
				#print "Volunteer: ",line
				volunteer_count = volunteer_count + 1

	with open('ack_received.txt','rb') as f3:
			for line in (f3.readlines()):
				#print "Volunteer: ",line
				ack_count = ack_count + 1
	#print "ack_count",ack_count
	f2.write(str(volunteer_count))	#not writing in file
	print "In while loop"
	with open('all_volunteers.txt','rb') as f1:
		for line in (f1.readlines()):
			print "Volunteer: ",line
			adr = line.strip('\n')
			adr = adr.strip()
			print type(ip)
			str_ip = str(ip)
			print type(str_ip)
			print type(adr)
			print "---",str_ip,"..."
			print "---",adr,"..."
	#if((volunteer_count is 1) and (adr <> str_ip)):
	if((volunteer_count is 1) and (adr == str_ip)):
		print "Im the only leader volunteer. Start ed-afd algo."		
		s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
		s.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
		dest = ('<broadcast>',11122)
		#print "ack_count FINAL",ack_count
		s.sendto(str_ip+" "+str(ack_count),dest)
		print "Sent"

	else:
		print "Im the not only leader volunteer."
		os.system("python multicast_receive.py")

						
					
f1.close()
#f2.close()
