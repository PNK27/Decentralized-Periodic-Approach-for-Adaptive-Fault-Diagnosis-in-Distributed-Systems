import socket
import re
import os
import sys

f = open('ack_sent.txt', 'r')
leader_elected_by_me=f.read()
le=re.findall(r"\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}",leader_elected_by_me)
print "LE is ",le
f.close()   

f1=open('leader_volunteer.txt','r')
bleh=f1.read()
print "bleh:",bleh

f1.close()


host=le[0]
port=10110
data = bleh
print data

address=host,port
s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
#s.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
#s.bind(address)
s.sendto(data,address)

s.close()
