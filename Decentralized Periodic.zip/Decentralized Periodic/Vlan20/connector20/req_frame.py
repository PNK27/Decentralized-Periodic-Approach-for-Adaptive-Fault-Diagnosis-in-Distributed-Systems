import netifaces as ni
from cmpself_test import *



class req_frame:
	def __init__(self,ip,status=-1,leader=-1):
		self.ip=ip
		self.status=status
		self.leader=leader
		print "status in requestframe.py",self.status
		print "ip requestframe.py",ip
		print "leader in requestframe.py",self.leader





