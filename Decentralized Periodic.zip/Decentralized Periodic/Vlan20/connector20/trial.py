import socket
import netifaces as ni
import csv
import os
import sys
import traceback
import time
from cmpself_test import *
from request_frame import *
    #print socket.gethostname()
    #print socket.gethostbyname(socket.gethostname())
    #print socket.gethostbyaddr(socket.gethostbyname(socket.gethostname()))


fn=open("neighbour.txt",'r')
num_lines=sum(1 for line in open('neighbour.txt'))
print "NUMBER OF LINES: ",num_lines
fn.close()

array=ni.interfaces()
print "array",array[1]
ni.ifaddresses(array[1])
ip = ni.ifaddresses(array[1])[2][0]['addr']
print "ip",ip
msg = socket.gethostname()
dest = ('<broadcast>',10100)
s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
s.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
#s.sendto(msg, dest)
print "Looking for replies; press Ctrl-C to stop."

count=0
timeout=time.time()+5
broadcast=0

broadcast_received = 0
print "trial"
host = ''
port = 10100
#msg="sent ACK"
#s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
#s.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
s.bind((host,port))

timeout=time.time()+5

#____________________________________________________________________________
def get_ack(buf):
	print "I am getting ACK from",address
	global count
	count=count+1
	#print "I am getting ACK from",address


	if(count >0):
		print "Get acknowledgement"
		#print "I am getting ACK from",address
		#os.system("python client2.py") #allow to send ack
		print "address formattttttttt",address
		ad = ''.join(str(address));
		ad1 = ad.split()
		print "ad1",ad1
		ad2= ad1[0]
		ad4=ad1[1]
		print "ad4",ad4
		print "ad2",ad2
		print "ad2+ad4",ad2+ad4
		data = ad2+ad4
		ad3=ad2[2:15]
		ad5=ad4[0:5]

		f = open('ack_received.txt', 'a')
		print "ad3",ad3
		if (ad3 <>  ip):
			print "Writing the ips which are not from the same pc"
			#f.write(ad3+','+ad5+'\n')
			f.write(buf+'\n')
		f.close()        
		#f = open('ack_received.txt', 'r')

		with open('ack_received.txt')as f:
			ack_count=sum(1 for _ in f)
		print "Number of acks received by me:",ack_count
	
	
		
		   # os.remove("ack_received.txt")	
#____________________________________________________________________________



print "IN TRIAL FILE"
faulty_list=list()
buf2=list()
while(True):
	try:
		if broadcast==0 and broadcast_received==0:		#sending broadcast for first and last time
			print "In broadcast=0. sending broadcast"
			print "Sending msg"
			s.sendto(msg, dest)
			print"msg sent"
			broadcast=1
		if broadcast==1:		#already broadcast is sent. Receive acknowledgement from the clients
			#s.settimeout(5.0)
			print"Already broadcast is sent. Receive acknowledgement from the clients."
			while(True):			##########################
				s.settimeout(5.0)
				if time.time()<timeout: 
					print "Now waiting to receive in trial"
					(buf,address)=s.recvfrom(10100)
					buf2 = buf.split(',')		#ip,status
		                        print"\n\nbuf2",buf2,"\n\n"
					if(len(buf2)==2 and buf2[1]=='1'):
						faulty_list.append(buf2[0])
					#print "type(buf2[1])",type(buf2[1])
					#if(buf2[1]=='1'):
						#
					print "Buffer: IP + status",buf
					break	####################### break for ###############while loop
				#____________CONTINUE FROM HERE__________	
				'''os.system("python prob_leader.py")
				sys.exit()
				print "After calling"'''


			print "Buff",buf
			get_ack(buf)
			if os.path.isfile("test.csv"):	#if already a leader has requsted for its acknowledgement
		  		break
			

		
		
	
	except socket.timeout: #volunteer to become leader and send broadcast
		print "In timeout of trial"
               
                if(len(faulty_list)==num_lines):
			print "n-1 faulty nodes==> ",faulty_list
