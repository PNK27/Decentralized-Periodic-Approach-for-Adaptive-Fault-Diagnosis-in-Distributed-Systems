import os
import sys

os.system("python xyz.py 172.16.27.232")

