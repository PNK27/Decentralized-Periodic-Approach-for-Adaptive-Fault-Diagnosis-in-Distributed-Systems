#client

import socket 
import os
import sys

print "IN VLAN 30 CLIENT***********"
c=socket.socket(socket.AF_INET,socket.SOCK_STREAM)

host='172.16.30.101'
port=22375
address=host,port
#c.bind(address)
#c.listen(1)
c.setsockopt(socket.SOL_SOCKET,socket.SO_REUSEADDR,1)
#s,addr=c.accept()

c.connect(address)
fd=open("final_broadcast.txt","r")
contents=fd.read(1024)
#filename=raw_input("enter filename")

c.send(contents)

#contents=s.recv(1024)
#print contents

c.close()
'''
[root@localhost 3462]# systemctl stop firewalld.service
[root@localhost 3462]# systemctl stop iptables.service
[root@localhost 3462]# python socket1_clientpc.py
enter filenameabc.txt
Welcome To Cummins College.
'''

