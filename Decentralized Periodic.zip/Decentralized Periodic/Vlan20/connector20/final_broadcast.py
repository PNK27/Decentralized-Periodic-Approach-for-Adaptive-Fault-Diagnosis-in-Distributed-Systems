print "YOU WILL RECEIVE THE BROADCAST WHICH WILL TELL YOU THE FAULTY NODES IN YOUR NETWORK"

import socket
import socket,pickle
import netifaces as ni
import os
import sys
import time
s_final = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
s_final.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)

host_final = ''
port_final = 10444
s_final.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
s_final.bind((host_final,port_final))


print "receiving"
#while(True):
faulty_nodes_final, address_final = s_final.recvfrom(1024)
print "received"
print"\n\nFAUTLY NODES IN THE NETWORK ARE",faulty_nodes_final
final=open('final_broadcast.txt','a')
final.write("\n\nFAUTLY NODES IN THE NETWORK ARE\n\n")
for record in faulty_nodes_final:
		final.write(str(record))
final.write('\n')
final.close()


print "Executing init2.sh"

#__________________________________________periodic execution
counterfs = open('counter.txt','r')
counter = counterfs.read()
counter = int(counter)
print "COUNTER ACCESSED FROM FILE",counter

counter = counter - 1
print "COUNTER AND TYPE",counter," ",type(counter)
counterfs.close()

#_____________________________________

counterfs = open('counter.txt','w')
counterfs.write(str(counter))


print "COUNTER MODIFIED"

os.system("python vlan30client.py")
counterfs.close()
if(counter>0):
    
    print "COUNTERRRRRRRR",counter
    time.sleep(20)
    os.system("sh init2.sh")
sys.exit(1)
