import sys
a=sys.argv[1]

print"argv1",a,type(a)
