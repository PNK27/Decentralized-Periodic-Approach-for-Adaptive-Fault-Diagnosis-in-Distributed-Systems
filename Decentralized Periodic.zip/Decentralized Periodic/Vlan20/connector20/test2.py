#sending because leader

import time
import timeit
import socket
import socket, pickle
import json
import struct
import sys
import threading
from cmpself_test import *
from local_frame import *
from request_frame import *
from req_frame import *

print "\n\n\n\n**********************TEST 2 BEGINS*******************************\n\n\n"

if os.path.isfile("next_neighbourleader.txt"):
	os.remove("next_neighbourleader.txt")

#if os.path.isfile("last.txt"):
	#os.remove("last.txt")
#__________________________________________________________
#__________________________

f=open("neighbour.txt",'r')
host=f.read()
print "Host=",host



num_lines=sum(1 for line in open('neighbour.txt'))
print "count",num_lines
count_lines = num_lines


host1=host.strip('\n')
listofhosts=host.split('\n')
for line in range (0,num_lines):
	print"split",listofhosts[line]

#_________________________
port=10111

message = 'Send ip + status ton me(leader)'

sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)

#___________________________________________________________


#sock_faulty.bind((host,port_faulty))


first_leader=sys.argv[1:]
print "\n\nargv1",first_leader


print type(first_leader)

f1=open("neighbour.txt","rb")

lst = []
result_frame=[]
send_request=[]
new_neighbours_faulty=[]
send_request_new=[]

print "len(first_leader)",len(first_leader)



if(first_leader[0] == '1' and len(first_leader)==1):
	req["leader"]=1
	print "Req[Leader] when I am Leader from leader election Algoo",req["leader"]
        result_frame.append(req)
	print "&&&&&&&&&&&&&&&&&&&&&&&&&&first leader&&&&&&&&&&&&&&&&&&&"
	for i in range(0,num_lines):
	   sent = sock.sendto(message, (listofhosts[i],port))
else:
	pickle_in = open("dict.pickle","rb")
	result_frame = pickle.load(pickle_in)
	print "Req of me",req
	print "\n\n\n**********OUR RESULT FRAME IN TEST2**********",result_frame,"\n\n\n"
	nb=f1.read().split('\n')
	print "NB",nb
	
	

        req["leader"]=1
	print "Req[Leader] when i am the next leader",req["leader"]

        flag = 0
	ip_send = ""
	

	send_req_numbers = len(nb)-1
	present = 0
	for line in range(0,send_req_numbers):
		present = 0
		for record in result_frame:
			if(record["ip"]==req["ip"]):
				record["leader"]=1
			if (nb[line]==record["ip"]):	#same ip in frame as neighbour. Therefore dont send request
				present = 1
				print "Same IP in frame. Hence Dont send request to ip",record["ip"]
				#send_req_numbers = 
		if(present==0):
			print "IP: ", nb[line], "is not present in resullt frame. Hence append in send_request"
			send_request.append(nb[line])
			print "Send reuest Frame: ", send_request
			

           #flag=0
	print "\n\nFinal Send Request Frame: ",send_request
	print "count_lines==> ",count_lines
	
        print "type(result_frame)",type(result_frame)
	print "\n\n\n**********OUR RESULT FRAME IN TEST2 AFTER ME=LEADER**********",result_frame,"\n\n\n"


	print "LEN send request",len(send_request)
	for i in range(0,len(send_request)):
	   print "SENDING: ",message, " to ", send_request[i]
	   sent = sock.sendto(message, (send_request[i],port))

	print "Send Request: ",send_request
        count_lines = len(send_request)


#r = request_frame()
l = json.dumps(d) #local frame

print "Local frame", l
print "req original",req,type(req)

if any(str(req) in s for s in lst):
	print "The ip address of the string is already present in list"


lst.append(req)

print "lst",lst
print "\n\nTYPE lst=",type(lst)


r = json.dumps(req)
print "type(r)",type(r)
print "Request_frame",r
print "request Frame type",type(r)

print "in test2.py"



try:

    # Send data to the multicast group
    print >>sys.stderr, 'sending "%s"' % message


    print "count_lines",count_lines
    #start = timeit.default_timer()
    #start_time = timeit.start()
    start = time.time()

    while(count_lines>0):
        count_lines = count_lines-1
	print "COUNT_LINES" ,count_lines
	#_____________________________________________________________________________________________________________________
	try: 
		sock.settimeout(2.0)
		data, server = sock.recvfrom(1024)
		print "SERVER ADDRESS",server
		print "type(data)",type(data)
		    #dict_data = dict(data)
		    #s = "{'muffin' : 'lolz', 'foo' : 'kitty'}"
		json_acceptable_string = data.replace("'", "\"")
		dd = json.loads(json_acceptable_string)
		print "dd",dd
	       
		#changes done because tree faulty structure______________________________________________________________
		#port_faulty=10112
		#host='172.16.27.238'
		multicast_faulty_group = '224.3.29.75'
		server_address = ('',10144)
		sock_faulty = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
		sock_faulty.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
		#address_faulty = (host,port_faulty)
		sock_faulty.bind(server_address)
		#sock_faulty.listen(1)
		#conn,addr=sock_faulty.accept()
		# Tell the operating system to add the socket to the multicast group
		# on all interfaces.
		group = socket.inet_aton(multicast_faulty_group)
		mreq = struct.pack('4sL', group, socket.INADDR_ANY)
		sock_faulty.setsockopt(socket.IPPROTO_IP, socket.IP_ADD_MEMBERSHIP, mreq)

		
		print "\n\ndd[status]=",dd['status'],"\n\n"
		print "\n\ntype(dd[status])=",type(dd['status']),"\n\n"
		print "TYPE dd==",type(dd)
	
		if(dd['status']==1):
			f_new = open('neighbour_new.txt', 'a')
			send_request_new=[]
			print "\n\nCOUNT LINES BEFORE INCREMENTING FAULTY NODES: ",count_lines
			print "\n\nFaulty node: ",dd["ip"]," .Hence Take Its neighbours.txt file"
		        print "str(dd['ip'])",str(dd['ip'])
		        print "type of str(dd['ip'])",type(str(dd['ip']))
			#address_faulty = (str(dd['ip']),port_faulty)
		        #address_faulty = ('172.16.27.231',port_faulty)
			#print "address_faulty",address_faulty
		       
			#nb_recv_newneighbours, server = sock_faulty.recvfrom(1024)
		        nb_recv_newneighbours_tuple,addrs = sock_faulty.recvfrom(1024)
		        #conn.close()
			print "\n\nnb_recv_newneighbours_tuple",nb_recv_newneighbours_tuple,"\tTYPE= ",type(nb_recv_newneighbours_tuple),"\n\n"
			nb_recv_newneighbours = str(nb_recv_newneighbours_tuple)
			print "nb_recv_newneighbours",nb_recv_newneighbours
			new_neighbours_faulty = nb_recv_newneighbours.split('\n')
			print "new_neighbours_faulty",new_neighbours_faulty
			#detect common neighbours and do not send them request again
			my_neighbours=f1.read().split('\n')
			#sock_faulty.close()
			for line in range(0,len(new_neighbours_faulty)-1):
				present2 = 0
				for record in (0,len(my_neighbours)-1):
					if(my_neighbours[record]==new_neighbours_faulty[line]):
						print "Common neighbour found: ==>",new_neighbours_faulty[line]
						present2 = 1
				if(present2==0):
					present3=0
					print "\n\nIP: ", new_neighbours_faulty[line], "is not common neighbour.Hence now check  present in RF"
					#detect common neighbours from  result frame and do not send them request again
					for record2 in result_frame:
						if(record2["ip"]==new_neighbours_faulty[line]):
							present3=1
					if(present3==0):
						send_request_new.append(new_neighbours_faulty[line])
				print "\n\nSend reuest Frame NEW neighbours: ", send_request_new," \n\n"
				#sending request to new neighbours (neighbours of faulty node)
		        
			for i in range(0,len(send_request_new)):
				count_lines = count_lines + 1
				f_new.write(send_request_new[i]+'\n')
				message2 = 'Send ip + status ton me(leader)'
	   			print "SENDING: ",message, " to ", send_request_new[i]
				print "Address",port
	   			sent = sock.sendto(message2, (send_request_new[i],port))
				print "Sent2"
			

			f_new.close()
			print "\n\nCOUNT LINES AFTER INCREMENTING FAULTY NODES: ",count_lines
		#_________________________________________________________________________________________
		fa = open('next_neighbourleader.txt', 'a')
		fa.write(str(dd)+'\n')
		fa.close()
		    #t=str(ad3)
		lst.append(dd)
		print "Updated list", lst
		result_frame.append(dd)
		print "\n\nUpdated result frame\n",result_frame
	
		##########################################################
		entry = lst[1]
		print "type(entry)",type(entry)
		print "entry[ip]",entry["ip"]
		    #sock.sendto(entry["ip"], multicast_group)
		    
		print "type(req)",type(req)
		print "type(dd)",type(dd)
		    
		req.update()
		print "req",req
	
	except socket.timeout: #volunteer to become leader and send broadcast
		print "In timeout"
		f1.close()
		hardware_fault_ip=[]
		print "Result frame: ",result_frame
		fhw=open("neighbour.txt","rb")
		neighbours = fhw.read().split('\n')
		print "neighbours",neighbours,"$$$$$$$$$$$$$$$$$$$$$$$$$$$$"
		
		for line in range(0,len(neighbours)-1):
			present4 = 0
			for record in result_frame:
				if(record["ip"]==neighbours[line]):
					present4 =1
			if(present4 ==0):
				hardware_fault_ip.append(neighbours[line])
				print "Neighbour ",neighbours[line],"is not present in RESULT FRAME. Has hardware fault"
				
		for i in range(0,len(hardware_fault_ip)):
			rh = req_frame(hardware_fault_ip[i],1,0)
			hw_fault_nodes_frame = rh.__dict__
			lst.append(hw_fault_nodes_frame)
			result_frame.append(hw_fault_nodes_frame)
			print "REQUEST FRAME OF HARDWARE FAULT",rh.__dict__
				
		print "Handle hardware faults"
		print "\n\nResult_frame after appending hardware Faults: ",result_frame
		

	
	current_time = time.time()
	print "Current Time: ",current_time
	#if((current_time - start)>0.001):
		#break
	
    print "\n\nResult_frame FINALLLLL-------------->: ",result_frame    
    stop = time.time()
    #stop =  timeit.default_timer()
    print "Start Time",start
    print "Stop Time",stop
    print "Time Taken",stop-start
    print "lst outside while",lst
    print "Length of list: ",len(lst)
    num = 1
    while(True):
		print "IN WHILE LOOP OF num = ",num
                print "lst inside while",lst
		if(len(lst)==1):
			print "\n\nCONDITION: len(lst)==1 result_frame: ",result_frame,"\n\n\n"
			pickle_out = open("backtrack_dict.pickle","wb")
			pickle.dump(result_frame, pickle_out)
			pickle_out.close()
			print time.time()
			os.system("python backtrack_send.py")
			break
		leader = lst[num]
		print "leader ip",leader["ip"]
		print leader["status"]
		if(leader["status"]==0):
			print "The next leader is: ",lst[num] 	##############insert the code for passing the request frame to this.
			lst_data = pickle.dumps(result_frame)
			sent2 = sock.sendto(lst_data, (leader["ip"],port))
			print "\n\n Sent Pickled data to next leader==> ",leader["ip"]
                       	os.system("python backtrack_receive.py")
			break
		elif((num+1) >= len(lst)):
			print "No next leader in list" 	##################INSERT SOME BACKTRACKING CODE
			pickle_out = open("backtrack_dict.pickle","wb")
			pickle.dump(result_frame, pickle_out)
			pickle_out.close()
			os.system("python backtrack_send.py")
			break
		else:
			num = num+1
                
		
	
finally:
    print >>sys.stderr, 'closing socket'
    print "Exiting"
    sys.exit(0)
    print "Exited"


'''
if (not os.path.isfile("last.txt")):
print "Last.txt is absent"
os.system("python final_broadcast.py")

else:
print "Last.txt is present"
os.remove("last.txt")
print "Last.txt removed"
'''
	

