import json
import socket
import socket,pickle
import json


host =  '127.0.0.1'
port = 10011

sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
# Bind to the server address
sock.bind((host,port))


data, address = sock.recvfrom(1024)

lst = list()


lst = pickle.loads(data)
print "data_lst= ",lst


print "Type of lst: ",type(lst)

lst2 = list(lst)

lst2.append({"ip":"172.16.27.235","status":"0"})

print "List after appending: ",lst2

sock.close()
