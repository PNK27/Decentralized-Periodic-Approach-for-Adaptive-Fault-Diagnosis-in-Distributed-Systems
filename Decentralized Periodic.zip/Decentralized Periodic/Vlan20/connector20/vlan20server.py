#client

import socket 
import os
import sys

print "IN VLAN 20 SERVER***********"
c=socket.socket(socket.AF_INET,socket.SOCK_STREAM)
c.setsockopt(socket.SOL_SOCKET,socket.SO_REUSEADDR,1)

host='172.16.20.104'
port=22372
address=host,port
c.bind(address)
c.listen(1)

s,addr=c.accept()


contents=s.recv(1024)
print contents

fv = open("fromothervlan.txt","w")
fv.write(contents)
fv.close()
print "Written for broadcasting"
os.system("python broadcastfromothervlan.py")

c.close()


'''
[root@localhost 3462]# systemctl stop firewalld.service
[root@localhost 3462]# systemctl stop iptables.service
[root@localhost 3462]# python socket1_clientpc.py
enter filenameabc.txt
Welcome To Cummins College.
'''

