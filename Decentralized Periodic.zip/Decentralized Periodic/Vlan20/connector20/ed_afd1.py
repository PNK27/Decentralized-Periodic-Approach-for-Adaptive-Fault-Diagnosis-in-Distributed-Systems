import socket
import cPickle as pickle
import json
import struct
import sys
from cmpself_test import *
from local_frame import *
from request_frame import *


lst = []

#r = request_frame()
l = json.dumps(d) #local frame

print "Local frame", l
print "req original",req,type(req)
lst.append(req)

print "lst",lst


r = json.dumps(req)
print "type(r)",type(r)
print "Request_frame",r
print "request Frame type",type(r)

print "in ed_afd1.py"

message = 'Send ip + status ton me(leader)'
multicast_group = ('224.3.29.75', 11011)

# Create the datagram socket
sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
# Set a timeout so the socket does not block indefinitely when trying
# to receive data.
sock.settimeout(0.2)


# Set the time-to-live for messages to 1 so they do not go past the
# local network segment.
ttl = struct.pack('b', 1)
sock.setsockopt(socket.IPPROTO_IP, socket.IP_MULTICAST_TTL, ttl)


try:

    # Send data to the multicast group
    print >>sys.stderr, 'sending "%s"' % message
    sent = sock.sendto(message, multicast_group)

    # Look for responses from all recipients
    while True:
        print >>sys.stderr, 'waiting to receive'
        try:
            data, server = sock.recvfrom(1024)
            print "type(data)",type(data)
	    #dict_data = dict(data)
	    #s = "{'muffin' : 'lolz', 'foo' : 'kitty'}"
	    json_acceptable_string = data.replace("'", "\"")
	    dd = json.loads(json_acceptable_string)
	    print "dd",dd
	    lst.append(dd)
	    print "Updated list",lst
	    entry = lst[1]
	    print "type(entry)",type(entry)
	    print "entry[ip]",entry["ip"]
	    #sock.sendto(entry["ip"], multicast_group)
	    
	    print "type(req)",type(req)
	    print "type(dd)",type(dd)
            
	    req.update()
	    print "req",req
	    #req.update(data)
	    #print "data_dict",data_dict
	    data1 = json.dumps(data)
	    print "data1",data1
	    data2 = json.loads(data)
	    print "data2",data2
        except socket.timeout:
            print >>sys.stderr, 'timed out, no more responses'
            break
        else:
            print >>sys.stderr, '\nreceived "%s" \n from %s' % (data, server)
	
finally:
    print >>sys.stderr, 'closing socket'
    #sock.close()


