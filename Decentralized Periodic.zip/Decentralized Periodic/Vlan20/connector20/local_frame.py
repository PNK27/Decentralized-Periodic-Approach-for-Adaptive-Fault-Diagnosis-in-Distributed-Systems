import netifaces as ni
from cmpself_test import *



class local_frame:
	def __init__(self,ip,status=-1,leader=-1):
		array=ni.interfaces()
		print "array",array[1]
		ni.ifaddresses(array[1])
		ip = ni.ifaddresses(array[1])[2][0]['addr']
		print "ip",ip
		self.ip=ip
		self.status=status
		self.leader=leader
		print "status in local_frame.py",self.status
		print "ip in local_frame.py",ip
		print "leader in local_frame.py",self.leader





