#from selftest 
import csv
import os
import selftest
import netifaces as ni
from local_frame import *
from request_frame import *



arr2=[]
arr1=[]
flag=0
array=ni.interfaces()
print "array",array[1]
ni.ifaddresses(array[1])
ip = ni.ifaddresses(array[1])[2][0]['addr']
print "ip",ip

with open('selfresult.csv','rb') as csvfile:
	r=csv.reader(csvfile,delimiter=',')
	for row in r:
		arr1.append(row)

#os.system('python selftest.py')
with open('resultarr.csv', 'rb') as fp:
	r1=csv.reader(fp,delimiter=',')
	for row in r1:
		arr2.append(row)
#print arr1
#print arr2
if len(arr1)==len(arr2):
	i=0
	while(arr1[i]!=arr2[i]):
		flag=1
		break
else:
	flag=1

if(flag==0):
	print 'faultfree'
	fault_free=ip
	status=0
	leader = 0
	
	b=local_frame(ip,status,leader)
	r = request_frame(ip,status,leader)
	
	
else:
	print 'faulty'
	status=1
	leader= 0

	b=local_frame(ip,status,leader)
	r = request_frame(ip,status,leader)

d=b.__dict__	
req = r.__dict__	

f_cmp=open("cmp_selftest.txt","w")
f_cmp.write("comparision of self test done")
f_cmp.close()
