import socket
import socket,pickle
import netifaces as ni
import os
import sys
import time
s_final1 = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
s_final1.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)

host_final1 = ''
port_final1 = 10445
s_final1.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
s_final1.bind((host_final1,port_final1))


print "receiving"
#while(True):
faulty_nodes_final1, address_final1 = s_final1.recvfrom(1024)
print "received"
print"\n\nFAUTLY NODES IN THE NETWORK From OTHER VLAN ARE",faulty_nodes_final1

f_ovb=open("recv_other_vlan_broadcast.txt","w")
f_ovb.write(faulty_nodes_final1)
