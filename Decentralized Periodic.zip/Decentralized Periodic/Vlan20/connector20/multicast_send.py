import socket
import struct
import sys
import os
#from prob_leader_trial import *
import netifaces as ni

print "IN MULTICAST SEND"
#ack_count=5
ack_count=0
with open('ack_received.txt','rb') as f3:
	for line in (f3.readlines()):
		#print "Volunteer: ",line
		ack_count = ack_count + 1
print "Volunteer count in multicast_send",ack_count
message = "Vounteer Count From Other Leader"+str(ack_count)
multicast_group = ('224.3.29.72', 10001)

# Create the datagram socket
sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)

# Set a timeout so the socket does not block indefinitely when trying
# to receive data.
sock.settimeout(2)
array=ni.interfaces()
#print "array",array[1]
ni.ifaddresses(array[1])
ip2 = ni.ifaddresses(array[1])[2][0]['addr']

# Set the time-to-live for messages to 1 so they do not go past the
# local network segment.
ttl = struct.pack('b', 1)
sock.setsockopt(socket.IPPROTO_IP, socket.IP_MULTICAST_TTL, ttl)
sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)


ip_ackcount = dict()
count = 0

try:

    # Send data to the multicast group
    print >>sys.stderr, 'sending "%s"' % message
    sent = sock.sendto(message, multicast_group)

    # Look for responses from all recipients
    while True:
        print >>sys.stderr, 'waiting to receive'
        try:
            data, server = sock.recvfrom(16)
        except socket.timeout:
            print >>sys.stderr, 'timed out, no more responses'
            break
        else:
	    ip = server[0]
	    ack_count_new = data
	    ip_ackcount[ip]= ack_count_new
	    #ip_ackcount[1]= data
		
            print >>sys.stderr, 'received "%s" from %s' % (data, server)
	print "ip_ackcount",ip_ackcount

finally:
    maxack=0
    ip_ackcount[ip2] = ack_count
    print "ip_ackcount",ip_ackcount
    print >>sys.stderr, 'closing socket'
    sock.close()
    for key in ip_ackcount:
        full=ip_ackcount[key]
        print"FULL====",full
        if (int(full)>int(maxack)):
            print "IN if"
            print "FULL in IF",full
            print "maxack in IF",maxack
	    maxack=full
            print "maxack in IF after assign",maxack
            
	    ipofmax=key
            print "ipofmax last in IF",ipofmax
    print "maxack",maxack
    print "maxack",type(maxack)
    print "ack_count",ack_count
    '''if ack_count>int(maxack):
        print "In vc"
        maxack=ack_count
        ipofmax=ip2'''
    print "ipofmax,maxack",ipofmax,maxack
        
    #print "Volunteer Count of other leader is ",data
    if(ipofmax == ip2):
    	print "I am the leader"
        print "The leader is",ipofmax
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
	s.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
	dest = ('<broadcast>',11122)
	#The leader is someone else so start test1 after sending
	s.sendto(ipofmax+' '+str(maxack),dest)
	print "Sent from condition I am the leader"
        #os.system("python test2.py 1")

    else:
	print "The leader is",ipofmax
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
	s.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
	dest = ('<broadcast>',11122)
	#The leader is someone else so start test1 after sending
	s.sendto(ipofmax+' '+maxack,dest)
	print "Sent"
        
