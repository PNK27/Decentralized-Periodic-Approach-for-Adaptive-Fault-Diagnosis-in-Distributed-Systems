print "YOU WILL RECEIVE THE BROADCAST WHICH WILL TELL YOU THE FAULTY NODES IN YOUR NETWORK"

import socket
import socket,pickle
import netifaces as ni
import os
import sys
import time
s_final1 = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
s_final1.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
s_final1.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)



dest_final1 =  ('<broadcast>',10445)


#time.sleep(1)

HPH = open("fromothervlan.txt",'r')
contentstobroadcast = HPH.read()
print "SENDING TO MY VLAN: ",contentstobroadcast
s_final1.sendto(contentstobroadcast, dest_final1)

print "Sent final broadcast received from other vlan"

s_final1.close()

