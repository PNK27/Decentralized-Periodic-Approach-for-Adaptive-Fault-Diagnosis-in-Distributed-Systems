import socket
import struct
import sys
import os
import time
import netifaces as ni
#from prob_leader_trial import *


print "IN MULTICAST RECEIVE"
#ack_count=5
multicast_group = '224.3.29.72'
server_address = ('', 10001)


# Set a timeout so the socket does not block indefinitely when trying
# to receive data.
#sock.settimeout(2)
array=ni.interfaces()
#print "array",array[1]
ni.ifaddresses(array[1])
ip2 = ni.ifaddresses(array[1])[2][0]['addr']

ack_count=0
with open('ack_received.txt','rb') as f3:
	for line in (f3.readlines()):
		#print "Volunteer: ",line
		ack_count = ack_count + 1


# Create the socket
sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)

# Bind to the server address
sock.bind(server_address)

# Tell the operating system to add the socket to the multicast group
# on all interfaces.
group = socket.inet_aton(multicast_group)
mreq = struct.pack('4sL', group, socket.INADDR_ANY)
sock.setsockopt(socket.IPPROTO_IP, socket.IP_ADD_MEMBERSHIP, mreq)

leader_ack_count_received = 0


try:
	sock.settimeout(5.0)
	# Receive/respond loop
	while True:
	    print >>sys.stderr, '\nwaiting to receive message'
	    data, address = sock.recvfrom(1024)
	    leader_ack_count_received = 1
	    
	    print >>sys.stderr, 'received %s bytes from %s' % (len(data), address)
	    print >>sys.stderr, data

	    print >>sys.stderr, 'sending volunteer count to', address
	    sock.sendto(str(ack_count), address)

except socket.timeout: 
			print "In timeout multicast_receive. "
			if(leader_ack_count_received == 0):
				os.system("python multicast_send.py")
			'''if(leader_ack_count_received == 1):
				ss = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
				ss.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
				ss.bind((ip2,10102))
				buff,adr = ss.recvfrom(1024)
				print buff'''


