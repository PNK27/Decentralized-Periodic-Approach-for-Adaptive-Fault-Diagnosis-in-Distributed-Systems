import netifaces as ni
from cmpself_test import *



class request_frame:
	def __init__(self,ip,status=-1,leader=-1):
		array=ni.interfaces()
		print "array",array[1]
		ni.ifaddresses(array[1])
		ip = ni.ifaddresses(array[1])[2][0]['addr']
		print "ip",ip
		self.ip=ip
		self.status=status
		self.leader=leader
		print "status in requestframe.py",self.status
		print "ip requestframe.py",ip
		print "leader in requestframe.py",self.leader





