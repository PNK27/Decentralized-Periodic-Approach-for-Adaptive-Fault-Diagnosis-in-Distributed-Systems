import socket
import netifaces as ni
import csv
import os
import sys
import traceback
import time
import socket, pickle

print "TIME",time.time()
print "You are in backtract_receive"

array=ni.interfaces()
print "array",array[1]
ni.ifaddresses(array[1])
ip = ni.ifaddresses(array[1])[2][0]['addr']
print "ip",ip
#print "type of ip",type(ip)

host = ''
port = 11133
#msg="sent ACK"
s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
s.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
#s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
#s.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
s.bind((host,port))

message_backtrack, address = s.recvfrom(10104)


print "GETTING RESULT FRAME FROM : ", address[0]
result_frame = pickle.loads(message_backtrack)
print "RESULT FRAME in BACKTRACK RECEIVE",result_frame


pickle_out = open("backtrack_dict.pickle","wb")
print "\n\nRESULT FRAME in BACKTRACK RECEIVE FOR WRITING IN PICKLE FORM \n\n",result_frame
pickle.dump(result_frame, pickle_out)
pickle_out.close()

revisit_type2 = 0

f1 = open('neighbour.txt','rb')
contents = f1.read().split('\n')
print "contents",contents

if os.path.isfile("neighbour_new.txt"):
	f_new = open('neighbour_new.txt','rb')
	contents_new = f_new.read().split('\n')
	print "contents_new",contents_new

if os.path.isfile("neighbour_new.txt"):
	f_new.close()

all_leaders_done = 0

unexplored_neighbours=[]
unexplored_notmy_neighbours=[]
for entry in result_frame:
	if(entry["leader"]==0 and entry["status"]==0):
		if any(entry["ip"] in contents[s] for s in range(0,len(contents)-1)):
			print "Entry: ",entry["ip"] , "has not become a leader yet and is my neighbour"
			new_leader_host = entry["ip"]
			unexplored_neighbours.append(entry["ip"])
		elif (os.path.isfile("neighbour_new.txt")):
			if any(entry["ip"] in contents_new[s] for s in range(0,len(contents_new)-1)):
				print "Entry: ",entry["ip"] , "has not become a leader yet and is my faulty neighbour's children."
				new_leader_host = entry["ip"]
				unexplored_neighbours.append(entry["ip"])
	        	else:
				print "Entry: ",entry["ip"] , "has not become a leader yet and is not my neighbour. So backtrack to parent"
				unexplored_notmy_neighbours.append(entry["ip"])
				#os.system("python backtrack_receive.py")
				#break
		else:
			print "Entry: ",entry["ip"] , "has not become a leader yet and is not my neighbour. So backtrack to parent"
			unexplored_notmy_neighbours.append(entry["ip"])
			#os.system("python backtrack_receive.py")
	else:
		all_leaders_done = all_leaders_done + 1
		if(entry["status"]==1):
			print "Entry: ",entry["ip"], "was faulty so cant make it a leader."
		if(entry["leader"]==1):
			print "Entry: ",entry["ip"], "was already a leader so cant make it a leader."


print "all_leaders_done",all_leaders_done
print "len(result_frame)",len(result_frame)
print "unexplored_neighbours",unexplored_neighbours
#print "New_leader_host",unexplored_neighbours[0]
new_leader_port=10111


if(unexplored_neighbours==[] and len(result_frame)==all_leaders_done):
	#final_f1=open("last.txt","w")
	#final_f1.write("I am sending the final broadcast")
	print "ALL NODES EXPLORED.BROADCAST FAULTY NODES OF RESULT FRAME:",result_frame
	faulty_nodes = []
	for record in result_frame:
		if(record["status"]==1):
			faulty_nodes.append(record)
	print "Faulty nodes are",faulty_nodes
	#time.sleep(4)
	dest_final =  ('<broadcast>',10444)
	s_final = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
	s_final.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
	s_final.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
	time.sleep(1)
	s_final.sendto(str(faulty_nodes), dest_final)
	print "Sent"
	sys.exit()


lst_data = pickle.dumps(result_frame)
#sent2 = s.sendto(lst_data, (host1,port))

if(len(unexplored_neighbours)>0):
	s.sendto(lst_data ,(unexplored_neighbours[0],new_leader_port))
	print "Sent"

print len(unexplored_neighbours)
number_unexplored_neighbours_remaining = len(unexplored_neighbours)

print "number_unexplored_neighbours_remaining",number_unexplored_neighbours_remaining

if(number_unexplored_neighbours_remaining>0):
	print "((((((((((((((((((((IN IF LOOP OF AGAIN CALLING BACKTRACK RECEIVE)))))))))))))))))))))))))))))))))))))"
	os.system("python backtrack_receive.py")
print "Back from RECEIVEEEEEE mode"
if(len(unexplored_notmy_neighbours)>0):
	print "((((((((((((((((((((IN IF LOOP CALLING BACKTRACK SEND NOT MY NEIGHBOUR)))))))))))))))))))))))))))))))))))))"
	os.system("python backtrack_send.py")
