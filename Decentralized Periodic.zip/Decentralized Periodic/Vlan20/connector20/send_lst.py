import json
import socket
import socket,pickle



host =  '127.0.0.1'
port = 10011


address = (host,port)

sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)

lst = list()

#lst = ({"ip":"172.16.27.231","status":"0"},{"ip":"172.16.27.232","status":"0"})
lst = [{'status': 0, 'ip': u'172.16.27.232'}, {u'status': 0, u'ip': u'172.16.27.231'}]
print "Sending list: ",lst
lst_data = pickle.dumps(lst)


sock.sendto(lst_data, address)

