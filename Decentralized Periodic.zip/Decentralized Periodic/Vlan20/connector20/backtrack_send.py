print "You are in backtrack_send"
import socket
import netifaces as ni
import csv
import os
import sys
import traceback
import time
import socket,pickle

print time.time()
array=ni.interfaces()
print "array",array[1]
ni.ifaddresses(array[1])
ip = ni.ifaddresses(array[1])[2][0]['addr']
print "ip",ip
#print "type of ip",type(ip)

fp=open('parent.txt','r')
host=fp.read()
print "parent is ",host

host1=str(host)

print "host1",host1
host1=host1
port = 11133
#msg="sent ACK"
s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
s.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
#s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
#s.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)


print time.time()
message="You are my parent..imma backtrack to you"

pickle_in = open("backtrack_dict.pickle","rb")
result_frame = pickle.load(pickle_in)
#print "Req of me",req
print "\n\n\n**********OUR RESULT FRAME IN BACKTRACK_SEND**********",result_frame,"\n\n\n"

lst_data = pickle.dumps(result_frame)
time.sleep(5)
sent2 = s.sendto(lst_data, (host1,port))
print "\n\nSent data to parent",host1

fp.close()
