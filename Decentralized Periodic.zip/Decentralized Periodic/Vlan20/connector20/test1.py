#Receiving from leader
from collections import defaultdict
import socket
import struct
import sys
import cPickle as pickle
from cmpself_test import *
from local_frame import*
import json
import time

#multicast_group = '224.3.29.76'
#server_address = ('', 11010)

multicast_faulty_group = ('224.3.29.75', 10144)

if os.path.isfile("last.txt"):
	os.remove("last.txt")

print "in test1.py"


if os.path.isfile("neighbour_new.txt"):
	os.remove("neighbour_new.txt")
#__________________________
host=''
port=10111
port_faulty=10112
#f=open("neighbour.txt",'r')
#host=f.read()
#print "Host=",type(host)

#host1=unicode(host,"utf-8")
#print "host1",type(host1)
#_________________________

msg=json.dumps(d)
msg1 = json.loads(msg)
#print data1
print "Data",msg
print "Data1",msg1

faulty=0

if(d["status"]==1):
        faulty=1
	print "I am a faulty node"



# Create the socket
sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
# Bind to the server address
sock.bind((host,port))


#________________________________

sock_faulty = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
sock_faulty.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
# Bind to the server address
#sock_faulty.bind((host,port_faulty))

ttl = struct.pack('b', 1)
sock_faulty.setsockopt(socket.IPPROTO_IP, socket.IP_MULTICAST_TTL, ttl)
sock_faulty.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)

# Tell the operating system to add the socket to the multicast group
# on all interfaces.
'''group = socket.inet_aton(multicast_group)
mreq = struct.pack('4sL', group, socket.INADDR_ANY)
sock.setsockopt(socket.IPPROTO_IP, socket.IP_ADD_MEMBERSHIP, mreq)'''

recv_count = dict()
recv_count = defaultdict(lambda:0,recv_count)

lst = list()
lst2 = list()
# Receive/respond loop
while True:
    print >>sys.stderr, '\nwaiting to receive message'
    data, address = sock.recvfrom(1024)
    
    print "\n\nADDRESS",address,"\n\n"
    current_address = address[0]
    recv_count[current_address] =  recv_count[current_address]+1
    print "**********************recv_count************************",recv_count[current_address]

    print >>sys.stderr, 'received %s bytes from %s' % (len(data), address)

    #data, address = sock.recvfrom(1024)

    print "Data before pickling",data 


   
    #lst2 = list(lst)

    #lst2.append({"ip":"172.16.27.235","status":"0"})


    print >>sys.stderr, data

    if(data == 'Send ip + status ton me(leader)'):
    	print >>sys.stderr, 'sending acknowledgement to', address
    	sock.sendto(msg, address)
    #recv_count[address] = recv_count[address]+1
    else:							#(recv_count[current_address] == 2):
	print "MY PARENT IS:",address[0] #host,port so 0th is host
	pf=open("parent.txt","w+")
	pf.write(address[0])
	print "\n************************I am the next elected leader************************\n"
	lst = pickle.loads(data)
        print "data_lst= ",lst
        print "Type of lst: ",type(lst)
	pf.close()
        
	pickle_out = open("dict.pickle","wb")
	pickle.dump(lst, pickle_out)
	pickle_out.close()
	os.system("python test2.py 2")
	break

    
    if(faulty==1):
       # sock_faulty.connect((address[0],port_faulty))
        print"send my neighbour.txt to my parent ip=",address[0]
        f4=open("neighbour.txt",'r')
        nb2=f4.read()
        print "I am faulty and I am sending my neighbours =",nb2
	time.sleep(4)
        sent1=sock_faulty.sendto(nb2,multicast_faulty_group)
	sock_faulty.close()
    print "sent from test1"
