from cmpself_test import *
if status==0:
    print "starting together for fault free"
    os.system("python together.py")
if status==1:
	os.system("python faulty.py")
