import socket
import netifaces as ni
import csv
import os
import sys
import traceback
import time

array=ni.interfaces()
print "array",array[1]
ni.ifaddresses(array[1])
ip = ni.ifaddresses(array[1])[2][0]['addr']
print "ip",ip
#print "type of ip",type(ip)

host = ''
port = 11122
#msg="sent ACK"
s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
s.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
#s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
#s.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
s.bind((host,port))

message, address = s.recvfrom(10104)
print "message", message

message1=message.split(' ')
print "only ip extracted for comparision",message1[0]
#print "type of message[0]",type(message[0])



if(str(ip)<>message1[0]):
	print "Im in test1"
	os.system("python test1.py")
else:
	time.sleep(1)
	print "Im in test2"
	os.system("python test2.py 1") #am the leader form leader election algo so my argv is 1
	print "Exiting from recv.py"
	sys.exit(0)
	print "Exited from recv.py"
	
